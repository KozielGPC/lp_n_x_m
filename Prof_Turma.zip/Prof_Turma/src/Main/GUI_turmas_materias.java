package Main;

import DAOs.DAOGenerico;
import DAOs.DAOMateria;
import DAOs.DAOTurma;
import Entidades.Materia;
import Entidades.Professor;
import Entidades.Turma;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import static java.awt.Frame.NORMAL;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.DefaultCaret;
import myTools.Ferramentas;
import myTools.UsarGridBagLayout;

/**
 *
 * @author radames
 */
class GUI_turmas_materias extends JDialog {

    private Container cp;
    GridBagConstraints cons = new GridBagConstraints();
    GridBagLayout GridBagLayout = new GridBagLayout();
    JComboBox comboBox = new JComboBox();
    DateTextField dateTextField1 = new DateTextField();
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
    Date date = new Date();
    private JColorChooser colorchooser = new JColorChooser();

    private CardLayout CardLayout = new CardLayout();
    private BorderLayout BorderLayout = new BorderLayout();
    private JPanel pnNorte = new JPanel(BorderLayout);
    private JPanel pnCentro = new JPanel(GridBagLayout);
    private JPanel pnSul = new JPanel(CardLayout);
    private JPanel pnSulMsg = new JPanel();
    private JPanel pnSulListagem = new JPanel(new GridLayout(1, 1));

    private JPanel pnCard = new JPanel(CardLayout);
    private JPanel pnMateria = new JPanel(new BorderLayout());
    private JPanel pnAluno = new JPanel(new BorderLayout());
    private JPanel pnNorteNorte = new JPanel(new FlowLayout(FlowLayout.LEFT));
    private JPanel pnNorteSul = new JPanel(GridBagLayout);

    private JLabel lbId = new JLabel("Código Turma");
    private JLabel lbMaterias = new JLabel("Matérias");

    private JCheckBox checkbox = new JCheckBox("Cor do layout personalizada");

    private JTextField tfID = new JTextField(5);
    private JTextField tfNome = new JTextField(30);
    private JTextField tfEmailProfessor = new JTextField(30);

    private JButton btBuscar = new JButton("Buscar");
    private JButton btNBuscar = new JButton("Nova busca");
    private JButton btInserir = new JButton("Vincular");
    private JButton btAlterar = new JButton("Alterar");
    private JButton btExcluir = new JButton("Desvincular");
    private JButton btListar = new JButton("Listar");
    private JButton btSalvar = new JButton("Salvar");
    private JButton btCancelar = new JButton("Cancelar");
    private JButton btGravar = new JButton("Gravar");
    private JButton btMateria = new JButton();
    private JButton btAluno = new JButton();
    private JButton btProfessor = new JButton();
    private JButton btVoltar = new JButton("Menu");
    private JButton btExcluirTudo = new JButton("Excluir tudo e voltar ao menu");
    private JButton btCor = new JButton("Escolher cor");

    private Color color;

    String[] colunas = new String[]{"Código", "Nome", "CPF", "Data de Nascimento"};
    String[][] dados = new String[0][4];

    DefaultTableModel model = new DefaultTableModel(dados, colunas);
    JTable tabela = new JTable(model);

    JScrollPane scrollList = new JScrollPane();

    private JScrollPane scrollMensagem = new JScrollPane(); //barra de rolagem

    JTextArea textAreaMsg = new JTextArea(5, 150); //campo para texto com várias linhas

    private boolean inserindo; //esta variável controla se é uma operação de INSERT ou UPDATE no botão salvar

    DefaultCaret caret = (DefaultCaret) textAreaMsg.getCaret(); //para que haja rolagem automática do textArea

    String acao = "";

    DAOTurma daoTurma = new DAOTurma();
    DAOMateria daoMateria = new DAOMateria();

    List<Materia> materiaList = daoMateria.list();
    List<Turma> turmaList = daoTurma.list();

    Turma turma;
    Materia materia;
    Ferramentas fer = new Ferramentas();

    //métodos auxiliares
    private void setLog(String msg) {
        textAreaMsg.append(msg + "\n");
        textAreaMsg.setCaretPosition(textAreaMsg.getDocument().getLength());
    }

    private void travarTextFields(boolean campo) {
        tfID.setEditable(campo); //permite que o usuario digite nesse textField
        if (!campo) {
            tfNome.requestFocus();
            tfNome.selectAll();
        }
    }

    private void limparValoresDosAtributos() {
        comboBox.setSelectedIndex(0);
    }

    //construtor da classe GUI_Materia
    public GUI_turmas_materias() {
        //abrir o arquivo
        btCor.setVisible(false);
        comboBox.setEnabled(false);
        tabela.setEnabled(false);

        //faz com que a última linha do 
        //jTextArea seja exibida
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
        scrollMensagem.setViewportView(textAreaMsg);
        scrollMensagem.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);//esconde a barra horizontal

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        cp.add(pnMateria);
        pnNorte.add(pnNorteNorte, BorderLayout.NORTH);
        pnNorte.add(pnNorteSul, BorderLayout.SOUTH);

        pnNorteNorte.add(btVoltar);
        pnNorteNorte.add(lbId);
        pnNorteNorte.add(tfID);
        pnNorteNorte.add(btBuscar);
        pnNorteNorte.add(btNBuscar);
        btNBuscar.setVisible(false);
        pnNorteNorte.add(btInserir);
        pnNorteNorte.add(btAlterar);
        pnNorteNorte.add(btExcluir);
        pnNorteNorte.add(btSalvar);
        pnNorteNorte.add(btCancelar);
        pnNorteNorte.add(btListar);

        cons.fill = GridBagConstraints.BOTH;
        cons.gridy = 1;
        cons.gridx = 0;
        pnNorteSul.add(checkbox, cons);
        cons.fill = GridBagConstraints.BOTH;
        cons.gridy = 2;
        cons.gridx = 0;
        pnNorteSul.add(btCor, cons);

        cons.fill = GridBagConstraints.BOTH;
        cons.gridy = 0;
        cons.gridx = 0;
        pnCentro.add(lbMaterias, cons);
        cons.fill = GridBagConstraints.BOTH;
        cons.gridy = 0;
        cons.gridx = 1;
        pnCentro.add(comboBox, cons);

        comboBox.addItem(" ");
        for (int i = 0; i < materiaList.size(); i++) {
            comboBox.addItem(materiaList.get(i).getIdmateria() + "-" + materiaList.get(i).getNome());;
        }

        UsarGridBagLayout usarGridBagLayoutSul = new UsarGridBagLayout(pnSulMsg);
        usarGridBagLayoutSul.add(new JLabel("Registro de atividades"), scrollMensagem);
        pnSul.add(pnSulMsg, "pnMsg");
        pnSul.add(pnSulListagem, "pnLst");

        pnMateria.add(pnNorte, BorderLayout.NORTH);
        pnMateria.add(pnCentro, BorderLayout.CENTER);
        pnMateria.add(pnSul, BorderLayout.SOUTH);

        btBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Figuras/busca.png")));
        btNBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Figuras/busca.png")));
        btListar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Figuras/lista.jpg")));
        btAlterar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Figuras/alterar.png")));
        btExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Figuras/excluir.png")));
        btExcluirTudo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Figuras/excluir.png")));
        btVoltar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Figuras/voltar.jpg")));
        btCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Figuras/cancelar.png")));
        btSalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Figuras/salvar.png")));
        btInserir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Figuras/inserir.png")));
        btCor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Figuras/cor.jpg")));

        btExcluir.setToolTipText("Excluir");
        btVoltar.setToolTipText("Menu");
        btBuscar.setToolTipText("Buscar");
        btNBuscar.setToolTipText("Nova busca");
        btListar.setToolTipText("Listar");
        btSalvar.setToolTipText("Salvar");
        btInserir.setToolTipText("Inserir");
        btCancelar.setToolTipText("Cancelar");
        btAlterar.setToolTipText("Alterar");
        btExcluirTudo.setToolTipText("Apaga os dados e volta ao menu");
        btCor.setToolTipText("Escolher cor");

        btSalvar.setVisible(false);
        btCancelar.setVisible(false);
        btInserir.setVisible(false);
        btAlterar.setVisible(false);
        btExcluir.setVisible(false);

        travarTextFields(true);
        textAreaMsg.setEditable(false);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

//################ COLOR ##################
        btCor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                color = colorchooser.showDialog(null, "Escolher Cor", null);
                pnSulListagem.setBackground(color);
                pnSulMsg.setBackground(color);
                pnCentro.setBackground(color);
                pnNorteSul.setBackground(color);
                pnNorteNorte.setBackground(color);

            }
        });
//################## Check Box ##################33
        checkbox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (checkbox.isSelected() == false) {
                    pnSulListagem.setBackground(null);
                    pnSulMsg.setBackground(null);
                    pnCentro.setBackground(null);
                    pnNorteSul.setBackground(null);
                    pnNorteNorte.setBackground(null);
                    cp.setBackground(null);
                    btCor.setVisible(false);

                } else {

                    btCor.setVisible(true);
                    pnSulListagem.setBackground(color);
                    pnSulMsg.setBackground(color);
                    pnCentro.setBackground(color);
                    pnNorteSul.setBackground(color);
                    pnNorteNorte.setBackground(color);
                }
            }
        });

//############################# BOTAO VOLTAR #################################
        btVoltar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }

        });

//*********************** BOTÃO GRAVAR ****************************************
        btGravar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (inserindo) {
                    turma.setMateriaList((List<Materia>) materiaList.get((int) comboBox.getSelectedItem()));
                }
            }
        });

//###################### BOTAO EXCLUIR TUDO ################################
        btExcluirTudo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
// ------------------------BOTAO BUSCAR ----------------------------------------        
        btBuscar.addActionListener((ActionEvent e) -> {

            if (tfID.getText().trim().equals("")) {
                JOptionPane.showMessageDialog(cp, "Nenhuma informação passada ");
            } else {
                try {
                    tfID.setBackground(Color.green);
                    comboBox.setEnabled(false);
                    tfID.setEditable(false);
                    CardLayout.show(pnSul, "pnMsg");
                    turma = daoTurma.obter(Integer.valueOf(tfID.getText()));

                    if (turma == null) { //nao achou
                        btAlterar.setVisible(false);
                        btExcluir.setVisible(false);
                        limparValoresDosAtributos();
                        btBuscar.setVisible(false);
                        btNBuscar.setVisible(true);
                        setLog("Não achou na lista, procure outra turma");
                        System.out.println(materiaList);
                    } else { //achou
                        btAlterar.setVisible(true);
                        btExcluir.setVisible(true);
                        btInserir.setVisible(false);
                        btBuscar.setVisible(false);
                        btNBuscar.setVisible(true);
                        
                        for (Materia materia : materiaList) {
                            if (materia.getTurmaList().get(0).getMateriaList().get(0).getIdmateria() == materia.getIdmateria()) {
                                System.out.println(materia.getIdmateria() + "-" + materia.getNome());
                            }
                            
                        }
                        tfID.setText(String.valueOf(turma.getIdTurma()));
                        setLog("Achou [" + turma.getIdTurma() + "-" + turma.getNomeTurma() + ", com as materias"
                                + turma.getMateriaList() + "]");

                    }
                } catch (Exception x) {
                    tfID.selectAll();
                    tfID.requestFocus();
                    tfID.setBackground(Color.red);
                    tfID.setEditable(true);
                    setLog("Erro no tipo de dados da chave. (" + x.getMessage() + ")");
                }//else
            }
            tfID.selectAll();
            tfID.requestFocus();
        });

//########################3 Nova Busca ##########################3
        btNBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tfID.setEditable(true);
                btBuscar.setVisible(true);
                btNBuscar.setVisible(false);
                btAlterar.setVisible(false);
                btExcluir.setVisible(false);
                btInserir.setVisible(false);
                tfID.setText("");
                tfID.requestFocus();
                comboBox.setEnabled(false);
            }
        });
//*********************** BOTÃO SALVAR ****************************************        
        btSalvar.addActionListener((ActionEvent e) -> {
            if (inserindo) {
                turma = new Turma(); //criar um novo contato
            }
            //transfere os valores da GUI_Materia para classe contato
            turma.setIdTurma(Integer.valueOf(tfID.getText()));

            if (inserindo) { //a variavel inserindo é preenchida nos
                turma.setMateriaList(materiaList)
                setLog("Inseriu [" + professor.getIdProfessor() + "-" + professor.getNomeProfessor() + "-" + professor.getEmailProfessor() + "-" + professor.getNascimentoProfessor() + "]");
            } else {//alterar
                daoProfessor.atualizar(professor);
                setLog("Alterou [" + professor.getIdProfessor() + "-" + professor.getNomeProfessor() + "-" + professor.getEmailProfessor() + "-" + professor.getNascimentoProfessor() + "]");
            }

            //voltar para tela inicial
            tfID.setText("");
            comboBox.setEnabled(false);
            tfID.requestFocus();
            tfID.selectAll();
            btSalvar.setVisible(false);
            btCancelar.setVisible(false);
            btBuscar.setVisible(true);
            btListar.setVisible(true);
            limparValoresDosAtributos();
            travarTextFields(true);
        });

//**************** Cancelar alteração ou inclusão ********************
        btCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tfID.requestFocus();
                tfID.selectAll();
                tfID.setText("");
                comboBox.setEnabled(false);
                btInserir.setVisible(false);
                btSalvar.setVisible(false);
                btCancelar.setVisible(false);
                btBuscar.setVisible(true);
                btListar.setVisible(true);
                travarTextFields(true);
                limparValoresDosAtributos();
                setLog("Cancelou a alteração ou inclusão do registro");

            }
        });

//############################# BOTAO ALTERAR #################################
        btAlterar.addActionListener((ActionEvent e) -> {
            tfNome.requestFocus();
            btSalvar.setVisible(true);
            btCancelar.setVisible(true);
            btBuscar.setVisible(false);
            btAlterar.setVisible(false);
            btExcluir.setVisible(false);
            btListar.setVisible(false);
            btNBuscar.setVisible(false);
            inserindo = false;
            travarTextFields(false);
            comboBox.setEnabled(true);
            setLog("Alterando um registro existente");
        });
//||||||||||||||||||||||||||| BOTÃO INSERIR |||||||||||||||||||||||||||||||||||
        btInserir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tfNome.requestFocus();
                btInserir.setVisible(false);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btNBuscar.setVisible(false);
                btListar.setVisible(false);
                inserindo = true;
                travarTextFields(false);
                comboBox.setEnabled(true);
                limparValoresDosAtributos();
                setLog("Inserindo um novo registro");
            }
        });

//======================= LISTAR =============================================
        btListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CardLayout.show(pnSul, "pnLst");
                scrollList.setPreferredSize(tabela.getPreferredSize());
                pnSulListagem.add(scrollList);
                scrollList.setViewportView(tabela);
                //busca a lista de contatos
                String[] aux;
                colunas = new String[]{"Código", "Nome", "Email", "Data de Nascimento"};
                dados = new String[0][4];
                model.setDataVector(dados, colunas);
                List<Professor> professores = daoProfessor.listInOrderId();
                for (Professor a : professores) {
                    String nome = a.getNomeProfessor();
                    String nascimento = a.getNascimentoProfessor();
                    String email = a.getEmailProfessor();
                    int id = a.getIdProfessor();
                    String[] linha = new String[]{String.valueOf(id), nome, email, nascimento};
                    // String[] linha = new String[]{"João", "15", "Masculino"};
                    model.addRow(linha);
                }
            }
        });
//***************************** EXCLUIR *************************************
        btExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Materia materia = daoMateria.obter((int) comboBox.getSelectedItem());
                int id_turma = Integer.valueOf(tfID.getText());
                materia.getTurmaHasMateriaList().remove();
                int dialogResult = JOptionPane.showConfirmDialog(cp, "Vai desvincular [ "
                        + materia.getIdmateria() + "-" + materia.getNome() + " ]?", "Exclui da lista", NORMAL);
                if (dialogResult == JOptionPane.YES_OPTION) {
                    daoMateria.SetTurmas(turmaList);
                    setLog("Desvinculou [" + materia.getIdmateria()+ "-" + materia.getNome()+ "]");

                }
                tfID.setText("");
                tfID.requestFocus();
                btExcluir.setVisible(false);
                btAlterar.setVisible(false);
                comboBox.setEnabled(false);
                travarTextFields(true);
                btNBuscar.setVisible(false);
                btBuscar.setVisible(true);

            }

        });
//################# COLRO CHOOSER #################

//$$$$$$$$$$$$$$ FIM DOS LISTENERS $$$$$$$$$$$$$
        // parâmetros para janela inicial
        setSize(900, 400);
        setTitle("UZUM");
        setLocationRelativeTo(null);
        setModal(true);
        setVisible(true);
        setResizable(true);
    }
}
